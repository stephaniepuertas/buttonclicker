// function for logout button
function clicked (element){
    console.log ("log out");
    element.innerText = "log out";
}
// function for definition button
function deletedef (element){
    console.log (" ");
    element.remove()
}